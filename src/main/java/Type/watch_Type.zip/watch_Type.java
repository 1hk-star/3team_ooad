package Type;

public enum watch_Type {

    TIMEKEEPING, ALARM,WORLDTIME, STOPWATCH, DDAY,TIMER,FUNCTION, BUZZER
    //0				1    2				3		4	5		6      7
}
