package Mode;

import javax.swing.JButton;

public abstract class Mode {

    abstract public void work(JButton button);
}
